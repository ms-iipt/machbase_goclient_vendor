package machnet

import (
	"context"
	"crypto"
	"fmt"
	"sync"
	"time"

	"github.com/machbase/neo-client/v2/api"
)

// Lock hierarchy across this package (never acquire in the reverse order):
//
//	EnvHandle.mu     -> (never nests into ConnHandle.mu/StmtHandle.mu; Disconnect
//	                     always releases ConnHandle.mu before taking EnvHandle.mu)
//	ConnHandle.mu    -> NativeConn.stmtMu   (AllocStmt allocates a statement id)
//	StmtHandle.mu    -> NativeConn.mu       (Prepare/Execute/ExecDirect/Fetch send packets)
//
// NativeConn.mu and NativeConn.stmtMu are never nested into each other, and
// EnvHandle.mu/ConnHandle.mu/StmtHandle.mu are never held across a call into
// another handle's exported method beyond the two edges listed above.
type EnvHandle struct {
	mu      sync.Mutex
	closed  bool
	lastErr StatusError
	conns   map[*ConnHandle]struct{}
}

// Error() returns the last error code and message for the environment handle.
func (env *EnvHandle) Error() (int, string) {
	return env.lastErr.code, env.lastErr.msg
}

type ConnHandle struct {
	mu      sync.Mutex
	env     *EnvHandle
	native  *NativeConn
	closed  bool
	lastErr StatusError
}

// Error() returns the last error code and message for the connection handle.
func (conn *ConnHandle) Error() (int, string) {
	return conn.lastErr.code, conn.lastErr.msg
}

// IsOpen reports whether the connection has not been closed/disconnected yet.
// It also reports false once the underlying socket has been marked broken (see
// NativeConn.markBrokenLocked), which is how a desynchronized connection gets
// discarded by the database/sql pool instead of being handed out again.
func (conn *ConnHandle) IsOpen() bool {
	if conn == nil {
		return false
	}
	conn.mu.Lock()
	defer conn.mu.Unlock()
	return !conn.closed && conn.native != nil && !conn.native.isClosed()
}

type AppendState struct {
	table         string
	errCheckCnt   int
	columns       []ColumnMeta
	bindings      AppendBindings
	bindingNames  []string
	bindingsReady bool
	addCount      int64
	sentCount     int64
	successCnt    int64
	failCnt       int64
	pendingRows   [][]byte
	pendingBytes  int
	firstQueuedAt time.Time

	appendBatchMaxRows  int
	appendBatchMaxBytes int
	appendBatchMaxDelay time.Duration
}

func sameAppendBindingNames(left, right []string) bool {
	if len(left) != len(right) {
		return false
	}
	for i := range left {
		if normalizeIdentifier(left[i]) != normalizeIdentifier(right[i]) {
			return false
		}
	}
	return true
}

// See the lock hierarchy note above EnvHandle: stmt.mu is only ever nested
// as StmtHandle.mu -> NativeConn.mu (never the other way around).
type StmtHandle struct {
	mu        sync.Mutex
	conn      *ConnHandle
	id        uint32
	closed    bool
	prepared  bool
	sql       string
	stmtType  StmtType
	rowCount  int64
	rowID     uint64
	hasRowID  bool
	columns   []ColumnMeta
	paramDesc []ParamDesc
	rows      [][]any
	rowPos    int
	fetchLast bool
	fetchSize int64
	bound     map[int]BoundParam
	app       *AppendState
	lastErr   StatusError
}

// Error() returns the last error code and message for the statement handle.
func (stmt *StmtHandle) Error() (int, string) {
	return stmt.lastErr.code, stmt.lastErr.msg
}

func Initialize() (*EnvHandle, error) {
	return &EnvHandle{conns: map[*ConnHandle]struct{}{}}, nil
}

func (env *EnvHandle) Finalize() error {
	if env == nil {
		return nil
	}
	env.mu.Lock()
	if env.closed {
		env.mu.Unlock()
		return nil
	}
	env.closed = true
	conns := make([]*ConnHandle, 0, len(env.conns))
	for c := range env.conns {
		conns = append(conns, c)
	}
	env.mu.Unlock()
	for _, c := range conns {
		_ = c.Disconnect()
	}
	return nil
}

type ConnConfig struct {
	Host               string
	Port               int
	User               string
	Password           string
	AuthMode           string
	AuthSigScheme      string
	AlternativeServers []string
	FetchRows          int64
	TrackIOBytes       bool
	PrivateKey         crypto.PrivateKey
}

func (env *EnvHandle) Connect(cfg ConnConfig) (*ConnHandle, error) {
	if env == nil {
		return nil, makeClientErr("invalid environment")
	}
	if cfg.Host == "" {
		cfg.Host = "127.0.0.1"
	}
	if cfg.Port <= 0 {
		cfg.Port = 5656
	}
	if cfg.FetchRows <= 0 {
		cfg.FetchRows = defaultFetchRows
	}
	nc, err := dialNative(cfg)
	if err != nil {
		env.lastErr.setErr(err)
		return nil, err
	}
	ch := &ConnHandle{env: env, native: nc}
	env.mu.Lock()
	if env.closed {
		env.mu.Unlock()
		_ = nc.close()
		err = makeClientErr("environment closed")
		env.lastErr.setErr(err)
		return nil, err
	}
	env.conns[ch] = struct{}{}
	env.mu.Unlock()
	env.lastErr.setErr(nil)
	return ch, nil
}

func (conn *ConnHandle) IOMetrics() (readBytes uint64, writtenBytes uint64, enabled bool) {
	if conn == nil {
		return 0, 0, false
	}
	conn.mu.Lock()
	nc := conn.native
	conn.mu.Unlock()
	if nc == nil {
		return 0, 0, false
	}
	return nc.ioByteMetrics()
}

// SupportsDatabaseMetadata reports whether the server exposes logical database
// identifiers through the CMI 4.0.3 metadata contract.
func (conn *ConnHandle) SupportsDatabaseMetadata() bool {
	if conn == nil {
		return false
	}
	conn.mu.Lock()
	nc := conn.native
	conn.mu.Unlock()
	return nc != nil && nc.supportsV403()
}

func (conn *ConnHandle) ResetIOMetrics() (readBytes uint64, writtenBytes uint64, enabled bool) {
	if conn == nil {
		return 0, 0, false
	}
	conn.mu.Lock()
	nc := conn.native
	conn.mu.Unlock()
	if nc != nil {
		r, w, b := nc.ioByteMetrics()
		nc.resetIOByteMetrics()
		return r, w, b
	}
	return 0, 0, false
}

func (conn *ConnHandle) Disconnect() error {
	if conn == nil {
		return nil
	}
	conn.mu.Lock()
	if conn.closed {
		conn.mu.Unlock()
		return nil
	}
	conn.closed = true
	nc := conn.native
	conn.mu.Unlock()

	err := nc.close()
	conn.lastErr.setErr(err)
	if conn.env != nil {
		conn.env.mu.Lock()
		delete(conn.env.conns, conn)
		conn.env.mu.Unlock()
	}
	return err
}

func (conn *ConnHandle) AllocStmt() (*StmtHandle, error) {
	if conn == nil {
		return nil, makeClientErr("invalid connection")
	}
	conn.mu.Lock()
	defer conn.mu.Unlock()
	if conn.closed || conn.native == nil {
		err := makeClientErr("connection closed")
		conn.lastErr.setErr(err)
		return nil, err
	}
	id, err := conn.native.nextStmtID()
	if err != nil {
		conn.lastErr.setErr(err)
		return nil, err
	}
	stmt := &StmtHandle{
		conn:      conn,
		id:        id,
		fetchLast: true,
		fetchSize: conn.native.fetchRows,
		bound:     map[int]BoundParam{},
	}
	if stmt.fetchSize <= 0 {
		stmt.fetchSize = defaultFetchRows
	}
	conn.lastErr.setErr(nil)
	return stmt, nil
}

func (stmt *StmtHandle) Free() error {
	if stmt == nil {
		return nil
	}
	stmt.mu.Lock()
	if stmt.closed {
		stmt.mu.Unlock()
		return nil
	}
	stmt.closed = true
	conn := stmt.conn
	id := stmt.id
	stmt.mu.Unlock()
	var err error
	if conn != nil && conn.native != nil {
		err = conn.native.free(id)
		if err == nil {
			conn.native.releaseStmtID(id)
		}
	}
	stmt.lastErr.setErr(err)
	if conn != nil {
		conn.lastErr.setErr(err)
	}
	return err
}

func (stmt *StmtHandle) Prepare(ctx context.Context, query string) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	stmt.rowID = 0
	stmt.hasRowID = false
	if stmt.closed || stmt.conn == nil || stmt.conn.native == nil {
		err := makeClientErr("statement closed")
		stmt.lastErr.setErr(err)
		return err
	}
	res, err := stmt.conn.native.prepare(ctx, stmt.id, query)
	stmt.lastErr.setErr(err)
	stmt.conn.lastErr.setErr(err)
	if err != nil {
		return err
	}
	stmt.prepared = true
	stmt.sql = query
	stmt.columns = res.columns
	stmt.paramDesc = res.paramDesc
	stmt.stmtType = res.stmtType
	stmt.rowCount = res.rowCount
	stmt.rows = nil
	stmt.rowPos = 0
	stmt.fetchLast = true
	return nil
}

// SupportsReprepare reports whether the connected server accepts PREPARE on
// an existing statement id. CMI 4.0.3 servers use this to refresh metadata
// when a cached statement is reused after schema invalidation.
func (stmt *StmtHandle) SupportsReprepare() bool {
	if stmt == nil || stmt.conn == nil || stmt.conn.native == nil {
		return false
	}
	return stmt.conn.native.supportsV403()
}

func (stmt *StmtHandle) Execute(ctx context.Context) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	stmt.rowID = 0
	stmt.hasRowID = false
	if stmt.closed || stmt.conn == nil || stmt.conn.native == nil {
		err := makeClientErr("statement closed")
		stmt.lastErr.setErr(err)
		return err
	}
	if !stmt.prepared {
		err := makeClientErr("statement is not prepared")
		stmt.lastErr.setErr(err)
		return err
	}
	paramCnt := len(stmt.paramDesc)
	if paramCnt == 0 {
		for idx := range stmt.bound {
			if idx+1 > paramCnt {
				paramCnt = idx + 1
			}
		}
	}
	params := make([]BoundParam, paramCnt)
	for i := 0; i < paramCnt; i++ {
		if b, ok := stmt.bound[i]; ok {
			params[i] = b
		} else {
			params[i] = BoundParam{sqlType: api.SqlTypeString, isNull: true}
		}
	}
	res, err := stmt.conn.native.executePrepared(ctx, stmt.id, stmt.sql, params, stmt.columns)
	stmt.lastErr.setErr(err)
	stmt.conn.lastErr.setErr(err)
	if err != nil {
		return err
	}
	if res.stmtType != 0 {
		stmt.stmtType = res.stmtType
	}
	stmt.rowCount = res.rowCount
	stmt.rowID = res.rowID
	stmt.hasRowID = res.hasRowID
	if len(res.columns) > 0 {
		stmt.columns = res.columns
	}
	if len(res.paramDesc) > 0 {
		stmt.paramDesc = res.paramDesc
	}
	stmt.rows = res.rows
	stmt.rowPos = 0
	stmt.fetchLast = res.lastResult || len(stmt.columns) == 0
	if stmt.fetchSize <= 0 {
		stmt.fetchSize = defaultFetchRows
	}
	return nil
}

func (stmt *StmtHandle) ExecDirect(ctx context.Context, query string) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	stmt.rowID = 0
	stmt.hasRowID = false
	if stmt.closed || stmt.conn == nil || stmt.conn.native == nil {
		err := makeClientErr("statement closed")
		stmt.lastErr.setErr(err)
		return err
	}
	res, err := stmt.conn.native.execDirect(ctx, stmt.id, query)
	stmt.lastErr.setErr(err)
	stmt.conn.lastErr.setErr(err)
	if err != nil {
		return err
	}
	stmt.prepared = false
	stmt.sql = query
	stmt.stmtType = res.stmtType
	stmt.rowCount = res.rowCount
	stmt.rowID = res.rowID
	stmt.hasRowID = res.hasRowID
	stmt.columns = res.columns
	stmt.paramDesc = res.paramDesc
	stmt.rows = res.rows
	stmt.rowPos = 0
	stmt.fetchLast = res.lastResult || len(stmt.columns) == 0
	if stmt.fetchSize <= 0 {
		stmt.fetchSize = defaultFetchRows
	}
	return nil
}

func (stmt *StmtHandle) ExecuteClean() error {
	if stmt == nil {
		return nil
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	stmt.rows = nil
	stmt.rowPos = 0
	stmt.fetchLast = true
	stmt.rowID = 0
	stmt.hasRowID = false
	return nil
}

// FetchCompleted reports whether the server already delivered the last chunk of
// the current result set. While it is false the server keeps the cursor open
// ("Fetch in progress") and rejects the next Prepare/Execute on this statement
// id with MACHCLI-ERR-3008.
func (stmt *StmtHandle) FetchCompleted() bool {
	if stmt == nil {
		return true
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	return stmt.fetchLast
}

func (stmt *StmtHandle) NumParam() (int, error) {
	if stmt == nil {
		return 0, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	return len(stmt.paramDesc), nil
}

func (stmt *StmtHandle) DescribeParam(paramNo int) (ParamDesc, error) {
	if stmt == nil {
		return ParamDesc{}, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if paramNo < 0 || paramNo >= len(stmt.paramDesc) {
		return ParamDesc{Type: api.SqlTypeString, Nullability: api.NullabilityUnknown}, makeClientErr("invalid parameter index")
	}
	return stmt.paramDesc[paramNo], nil
}

func (stmt *StmtHandle) BindParam(paramNo int, sqlType api.SqlType, value any) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if paramNo < 0 {
		err := makeClientErr("invalid parameter index")
		stmt.lastErr.setErr(err)
		return err
	}
	if sqlType.IsArray() && !stmt.conn.native.supportsArray() {
		err := makeClientErr("ARRAY requires CMI 4.0.4 or later")
		stmt.lastErr.setErr(err)
		return err
	}
	bp := BoundParam{sqlType: sqlType, value: value, isNull: value == nil}
	if paramNo < len(stmt.paramDesc) && stmt.paramDesc[paramNo].Type.IsArray() {
		bp.cardinality = stmt.paramDesc[paramNo].Precision
		bp.elementPrecision = stmt.paramDesc[paramNo].ElementPrecision
		bp.scale = stmt.paramDesc[paramNo].Scale
	}
	// A text ARRAY literal (e.g. "[1,2,3]" or "[1=>1,2=>2]") is only
	// convertible here, where the target column's cardinality/precision/scale
	// from Describe are available. Without paramDesc metadata this falls
	// through unchanged and fails later at encode time as before.
	if sqlType.IsArray() && !bp.isNull && bp.cardinality > 0 {
		text, isText := value.(string)
		if raw, ok := value.([]byte); ok {
			text, isText = string(raw), true
		}
		if isText {
			array, err := api.ParseArray(text, sqlType.ElementType(), bp.cardinality, bp.elementPrecision, bp.scale)
			if err != nil {
				wrapped := makeClientErr(fmt.Sprintf("bind parameter %d: %v", paramNo+1, err))
				stmt.lastErr.setErr(wrapped)
				return wrapped
			}
			bp.value = array
		}
	}
	stmt.bound[paramNo] = bp
	stmt.lastErr.setErr(nil)
	return nil
}

func (stmt *StmtHandle) RowCount() (int64, error) {
	if stmt == nil {
		return 0, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	return stmt.rowCount, nil
}

// GeneratedRowID returns the generated ROWID for the most recent scalar INSERT.
func (stmt *StmtHandle) GeneratedRowID() (uint64, bool) {
	if stmt == nil {
		return 0, false
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	return stmt.rowID, stmt.hasRowID
}

func (stmt *StmtHandle) GetStmtType() (StmtType, error) {
	if stmt == nil {
		return 0, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if stmt.stmtType == 0 {
		return inferStmtType(stmt.sql), nil
	}
	return stmt.stmtType, nil
}

func (stmt *StmtHandle) NumResultCol() (int, error) {
	if stmt == nil {
		return 0, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	return len(stmt.columns), nil
}

func (stmt *StmtHandle) DescribeCol(columnNo int, pName *string, pType *api.SqlType, pSize *int, pScale *int, pNullable *bool) error {
	return stmt.DescribeColEx(columnNo, pName, pType, pSize, pScale, pNullable, nil, nil)
}

func (stmt *StmtHandle) DescribeColEx(columnNo int, pName *string, pType *api.SqlType, pSize *int, pScale *int, pNullable *bool, pNullability *api.Nullability, pPrimaryKey *bool) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if columnNo < 0 || columnNo >= len(stmt.columns) {
		err := makeClientErr("invalid column index")
		stmt.lastErr.setErr(err)
		return err
	}
	col := stmt.columns[columnNo]
	if pName != nil {
		*pName = col.name
	}
	if pType != nil {
		*pType = col.sqlType
	}
	if pSize != nil {
		sz := col.length
		if isArraySpinerType(col.spinerType) {
			sz = col.precision
		} else if col.spinerType == cmdDecimalType {
			sz = col.precision
		} else if col.isVariable {
			if sz <= 0 {
				sz = col.precision
			}
			if sz > 65536 {
				sz = 65536
			}
		}
		*pSize = sz
	}
	if pScale != nil {
		*pScale = col.scale
	}
	if pNullable != nil {
		*pNullable = col.nullable
	}
	if pNullability != nil {
		*pNullability = col.nullability
	}
	if pPrimaryKey != nil {
		*pPrimaryKey = col.primaryKey
	}
	return nil
}

func (stmt *StmtHandle) DescribeArrayCol(columnNo int, pElementType *api.SqlType, pElementPrecision *int) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if columnNo < 0 || columnNo >= len(stmt.columns) {
		return makeClientErr("invalid column index")
	}
	col := stmt.columns[columnNo]
	if !isArraySpinerType(col.spinerType) {
		return makeClientErr("column is not ARRAY")
	}
	if pElementType != nil {
		*pElementType = spinerTypeToSqlType(arrayBaseSpinerType(col.spinerType))
	}
	if pElementPrecision != nil {
		*pElementPrecision = col.elementPrecision
	}
	return nil
}

func (stmt *StmtHandle) Fetch(ctx context.Context) ([]any, error) {
	if stmt == nil {
		return nil, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	for {
		if stmt.rowPos < len(stmt.rows) {
			ret := stmt.rows[stmt.rowPos]
			stmt.rowPos++
			if stmt.rowPos >= len(stmt.rows) {
				stmt.rows = nil
				stmt.rowPos = 0
			}
			return ret, nil
		}

		if stmt.fetchLast || len(stmt.columns) == 0 {
			return nil, nil
		}
		if stmt.conn == nil || stmt.conn.native == nil {
			return nil, nil
		}

		rows, last, err := stmt.conn.native.fetchRowsChunk(ctx, stmt.id, stmt.columns, stmt.fetchSize)
		stmt.fetchLast = last
		stmt.lastErr.setErr(err)
		stmt.conn.lastErr.setErr(err)
		if err != nil {
			return nil, err
		}
		stmt.rows = rows
		stmt.rowPos = 0
		if len(stmt.rows) == 0 && stmt.fetchLast {
			return nil, nil
		}
	}
}

func (stmt *StmtHandle) AppendOpen(tableName string, errCheckCount int) error {
	return stmt.AppendOpenColumns(tableName, nil, errCheckCount)
}

func (stmt *StmtHandle) AppendOpenColumns(tableName string, columns []string, errCheckCount int) error {
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if stmt.closed || stmt.conn == nil || stmt.conn.native == nil {
		err := makeClientErr("statement closed")
		stmt.lastErr.setErr(err)
		return err
	}
	res, err := stmt.conn.native.appendOpen(stmt.id, tableName, columns, errCheckCount)
	stmt.lastErr.setErr(err)
	stmt.conn.lastErr.setErr(err)
	if err != nil {
		return err
	}

	stmt.app = &AppendState{
		table:       tableName,
		errCheckCnt: errCheckCount,
		columns:     append([]ColumnMeta(nil), res.columns...),
		bindings: AppendBindings{
			arrivalArg: -1,
		},
		appendBatchMaxRows:  512,
		appendBatchMaxBytes: 512 * 1024,
		appendBatchMaxDelay: 5 * time.Millisecond,
	}
	stmt.app.pendingRows = make([][]byte, 0, stmt.app.appendBatchMaxRows)
	return nil
}

func (atmt *StmtHandle) SetAppendBatchMaxRows(maxRows int) {
	if atmt == nil {
		return
	}
	atmt.mu.Lock()
	if atmt.app != nil {
		atmt.app.appendBatchMaxRows = maxRows
	}
	atmt.mu.Unlock()
}

func (atmt *StmtHandle) SetAppendBatchMaxBytes(maxBytes int) {
	if atmt == nil {
		return
	}
	atmt.mu.Lock()
	if atmt.app != nil {
		atmt.app.appendBatchMaxBytes = maxBytes
	}
	atmt.mu.Unlock()
}

func (atmt *StmtHandle) SetAppendBatchMaxDelay(maxDelay time.Duration) {
	if atmt == nil {
		return
	}
	atmt.mu.Lock()
	if atmt.app != nil {
		atmt.app.appendBatchMaxDelay = maxDelay
	}
	atmt.mu.Unlock()
}

func (stmt *StmtHandle) flushAppendBufferedLocked(checkResponse bool) error {
	if stmt == nil || stmt.app == nil || len(stmt.app.pendingRows) == 0 {
		return nil
	}
	pending := stmt.app.pendingRows
	pendingCount := len(pending)
	stmt.app.pendingRows = stmt.app.pendingRows[:0]
	stmt.app.pendingBytes = 0
	stmt.app.firstQueuedAt = time.Time{}

	err := stmt.conn.native.appendData(stmt.id, pending, checkResponse)
	stmt.lastErr.setErr(err)
	stmt.conn.lastErr.setErr(err)
	if err != nil {
		stmt.app.failCnt += int64(pendingCount)
		return err
	}
	stmt.app.sentCount += int64(pendingCount)
	return nil
}

func (stmt *StmtHandle) AppendData(types []api.SqlType, names []string, args []any, formats []string) error {
	_ = types
	_ = formats
	if stmt == nil {
		return makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if stmt.closed || stmt.conn == nil || stmt.conn.native == nil {
		err := makeClientErr("statement closed")
		stmt.lastErr.setErr(err)
		return err
	}
	if stmt.app == nil {
		err := makeClientErr("append not opened")
		stmt.lastErr.setErr(err)
		return err
	}
	if len(names) != len(args) {
		err := makeClientErr("append argument mismatch")
		stmt.lastErr.setErr(err)
		return err
	}
	if !stmt.app.bindingsReady || !sameAppendBindingNames(stmt.app.bindingNames, names) {
		bindings, err := buildAppendBindings(stmt.app.columns, names)
		if err != nil {
			stmt.lastErr.setErr(err)
			stmt.conn.lastErr.setErr(err)
			stmt.app.failCnt++
			return err
		}
		stmt.app.bindings = bindings
		stmt.app.bindingNames = append(stmt.app.bindingNames[:0], names...)
		stmt.app.bindingsReady = true
	}
	rowPayload, err := encodeAppendRow(stmt.app.columns, stmt.app.bindings, args, stmt.conn.native.serverEndian)
	if err != nil {
		stmt.lastErr.setErr(err)
		stmt.conn.lastErr.setErr(err)
		stmt.app.failCnt++
		return err
	}
	stmt.app.addCount++
	if len(stmt.app.pendingRows) == 0 {
		stmt.app.firstQueuedAt = time.Now()
	}
	stmt.app.pendingRows = append(stmt.app.pendingRows, rowPayload)
	stmt.app.pendingBytes += len(rowPayload)

	checkResponse := stmt.app.errCheckCnt > 0 && (stmt.app.addCount%int64(stmt.app.errCheckCnt) == 0)
	flushNow := checkResponse ||
		len(stmt.app.pendingRows) >= stmt.app.appendBatchMaxRows ||
		stmt.app.pendingBytes >= stmt.app.appendBatchMaxBytes
	if !flushNow &&
		stmt.app.appendBatchMaxDelay > 0 &&
		!stmt.app.firstQueuedAt.IsZero() &&
		time.Since(stmt.app.firstQueuedAt) >= stmt.app.appendBatchMaxDelay {
		flushNow = true
	}
	if flushNow {
		if err := stmt.flushAppendBufferedLocked(checkResponse); err != nil {
			return err
		}
	}
	return nil
}

func (stmt *StmtHandle) AppendClose() (int64, int64, error) {
	if stmt == nil {
		return 0, 0, makeClientErr("invalid statement")
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if stmt.app == nil {
		return 0, 0, nil
	}
	if err := stmt.flushAppendBufferedLocked(false); err != nil {
		localSuccess := stmt.app.sentCount - stmt.app.failCnt
		if localSuccess < 0 {
			localSuccess = 0
		}
		return localSuccess, stmt.app.failCnt, err
	}

	success, fail, err := stmt.conn.native.appendClose(stmt.id)
	stmt.lastErr.setErr(err)
	stmt.conn.lastErr.setErr(err)
	if err != nil {
		localSuccess := stmt.app.sentCount - stmt.app.failCnt
		if localSuccess < 0 {
			localSuccess = 0
		}
		return localSuccess, stmt.app.failCnt, err
	}
	stmt.app.successCnt = success
	stmt.app.failCnt = fail
	stmt.app = nil
	return success, fail, nil
}

func (stmt *StmtHandle) AppendFlush() error {
	if stmt == nil {
		return nil
	}
	stmt.mu.Lock()
	defer stmt.mu.Unlock()
	if stmt.app == nil || stmt.conn == nil || stmt.conn.native == nil {
		return nil
	}
	return stmt.flushAppendBufferedLocked(false)
}
